// import Image from "next/image";

import CoreSection from "@/components/CoreSection";
import Footer from "@/components/Footer";
import Hero from "@/components/Hero";


export default function Home() {
  return (
    <>
      <Hero/>
      <CoreSection/>
      {/* <Footer/> */}
    </>
    
  )
}
